package com.sscse.webcrawler.model;

/** Overall state of a crawl job (a job = one "start crawl" request with a seed URL). */
public enum CrawlJobState {
    PENDING,
    RUNNING,
    COMPLETED,
    STOPPED
}
