package com.sscse.webcrawler.model;

/** Lifecycle status of a single URL as it moves through the crawler. */
public enum CrawlStatus {
    QUEUED,      // waiting in the URL queue
    CRAWLING,    // currently being fetched/parsed
    CRAWLED,     // successfully fetched and links extracted
    FAILED,      // fetch failed (timeout, 404, connection error, etc.)
    SKIPPED      // rejected by validation (invalid / disallowed URL) or already visited
}
