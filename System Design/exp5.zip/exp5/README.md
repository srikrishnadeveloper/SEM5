# UCS3513 Lab Exercise 5 — Consistent Hashing over MongoDB

**Name:** Srikrishna O S  
**Register No:** 3122245001312  
**Class:** CSE Section A  
**Institution:** SSN College of Engineering  

## Aim

Deploy three MongoDB instances using Docker, implement Consistent Hashing in a Spring Boot application, distribute student records across storage nodes, and analyse data migration when nodes are added or removed. Only the affected records are re‑hashed and moved — the rest stay put.

## Algorithm

1. **Hash ring** — Each physical node is placed on a ring `virtualNodes` times (default 3). A key's position is `MD5(key) → long`. The node whose hash is *closest clockwise* owns the key.
2. **Virtual nodes** — Adding 3 virtual nodes per physical node ensures an even distribution even with only a few nodes.
3. **Routing a student record** — Hash the student's unique ID (rollNo). `ConsistentHashRing.getNode(id)` returns the responsible storage node. The `StudentService` inserts the record into that node's MongoDB collection.
4. **Adding a node** — `ring.addNode(name)` places the new node on the ring. After the ring updates, `migrateAffectedRecords()` scans every existing record; if its new hash target differs from its current node, the record is `INSERT`‑ed into the new node and `DELETE`‑ed from the old one. Only records whose ring position changed are moved.
5. **Removing a node** — `ring.removeNode(name)` removes the node. All records that had that node as their target are re‑hashed onto the remaining nodes via the same migration routine. The node's MongoClient is closed.
6. **Distribution endpoint** — `GET /api/students/distribution` returns a map `nodeName → recordCount`, enabling comparison of data distribution before and after adding/removing a node.

## Files (Experiment 5)

| File | Description |
|------|-------------|
| `ConsistentHashingApplication.java` | Spring‑Boot main class; starts the app on port 8080. |
| `Student.java` | Simple POJO modelling a student record (`rollNo`, `name`, `department`, `year`). Includes `toDocument()` / `fromDocument()` for MongoDB conversion. |
| `ConsistentHashRing.java` | Hash‑ring implementation (MD5, virtual nodes, `addNode`, `removeNode`, `getNode`). |
| `StorageNode.java` | Wraps a `MongoClient` + collection; provides `countDocuments()` for distribution reporting. |
| `StudentService.java` | Core service: `insertStudent`, `getStudent`, `distribution`, `addNode`, `removeNode`, and the migration routine `migrateAffectedRecords()`. All console output is prefixed with `[CH]` so it can be filtered easily. |
| `StudentController.java` | REST controller with endpoints: `POST /api/students`, `GET /api/students/{id}`, `GET /api/nodes/distribution`, `POST /api/nodes/add/{name}/{port}`, `POST /api/nodes/remove/{name}`. |
| `MongoNodeConfig.java` | Configures MongoDB templates for each storage node from `application.properties`. |
| `NodeManagerService.java` | Handles adding/removing nodes and migrating affected records. |
| `NodeController.java` | REST controller with endpoints `POST /api/nodes/add/{name}/{host}/{port}` and `POST /api/nodes/remove/{name}`. |
| `application.properties` | Configures the three MongoDB storage nodes, the number of virtual nodes, database/collection names, and the host‑port mapping. |
| `pom.xml` | Maven project file — Spring Boot 3.2.5, Java 17, `spring-boot-starter-data-mongodb`. |
| `app.log` | Server‑side console output (all `[CH]` lines + Spring Boot INFO). Used as the "application log" section of the PDF. |
| `demo_output.txt` | Captured `curl` output from the demo script (requests/responses). |

## Running the Experiment

### 1. Prerequisites

- **Java 17** (JDK 21 also works; the pom targets `java.version` = 17).
- **Maven** — portable binary is at `System Design\tools\apache-maven-3.9.9\bin\mvn.cmd`.
- **Docker Desktop** running with MongoDB containers.

### 2. Start the MongoDB containers

Open **PowerShell** and run:

```powershell
docker run -d --name mongo-node1 -p 27017:27017 mongo:7
docker run -d --name mongo-node2 -p 27018:27017 mongo:7
docker run -d --name mongo-node3 -p 27019:27017 mongo:7
```

Verify they are up:

```powershell
docker ps --format "{{.Names}} {{.Ports}}"
```

You should see three containers listening on host ports 27017, 27018, 27019 (all mapping to container internal port 27017).

### 2️⃣ Build the Spring Boot JAR

```powershell
& "C:\Users\srik2\Desktop\College\System Design\tools\apache-maven-3.9.9\bin\mvn.cmd" -f "C:\Users\srik2\Desktop\College\System Design\exp5\pom.xml" package -DskipTests
```

The JAR `consistent-hashing-lab-1.0.0.jar` is created in `exp5\target\`.

### 3️⃣ Launch the app

```powershell
java -jar "C:\Users\srik2\Desktop\College\System Design\exp5\target\consistent-hashing-lab-1.0.0.jar" > "C:\Users\srik2\Desktop\College\System Design\exp5\app.log" 2>&1 &
Start-Sleep -Seconds 8
```

The app auto‑configures the three nodes from `application.properties` and prints something like:

```
[CH] Initial ring with 3 storage nodes (3 virtual nodes per node, [node1:localhost:27017, node2:localhost:27018, node3:localhost:27019])
```

### 4️⃣ Exercise the APIs (capture demo output)

Use `curl` (PowerShell or a terminal). All `curl` output is redirected to `demo_output.txt`; the server‑side log appears in `app.log`.

```powershell
# A) POST a student record
curl -X POST http://localhost:8080/api/students `
     -H "Content-Type: application/json" `
     -d '{"rollNo":"CSE001","name":"Alice CSE","department":"CSE","year":3}'

# B) GET a student by ID (the app logs which node serves it)
curl http://localhost:8080/api/students/3122245001001

# C) GET current distribution (how many records on each node)
curl http://localhost:8080/api/nodes/distribution

# D) Add a 4th storage node (docker run --name mongo-node4 -p 27020:27017 mongo:7 first)
curl -X POST http://localhost:8080/api/nodes/add/node4/27020

# E) Remove node1
curl -X POST http://localhost:8080/api/nodes/remove/node1
```

All `curl` output was captured to `demo_output.txt`. The server‑side log (`app.log`) contains lines like:

```
[CH] Inserted student 3122245001001 (Alice CSE) -> routed by hash to node1 (port 27017)
[CH] Distribution: node1:27017=40, node2:27018=40, node3:27019=40
[CH] === Adding storage node node4 (port 27020) ===
[CH] Migrated 12 records from node2 to node4: [3122245001005, 3122245001009, ...]
[CH] Node node4 added. Migrated 12 records.
[CH] === Removing storage node node1 ===
[CH] Redistributed 12 records from node1 to node2/node3: [...]
[CH] Node node1 removed. Redistributed 12 records.
```

### 5. Verify the distribution (analysis)

- `GET /api/nodes/distribution` shows how many records each node holds.
- After `add node4`, the distribution shifts: some records move from node2/node3 to node4; the rest stay put.
- After `remove node1`, node1's records redistribute to node2/node3; other nodes' data is untouched.

## API Specification

| Endpoint | Method | Request body | Response | Description |
|---|---|---|---|---|
| `/api/students` | `POST` | `{ "rollNo":"CSE001", "name":"Alice CSE", "department":"CSE", "year":3 }` | `201 Created` + student JSON | Route the student to a node via the hash ring; insert into that node's MongoDB collection. |
| `/api/students/{id}` | `GET` | Path param `id` | `200 OK` + student JSON **or** `404 Not Found` | Look up the student by ID; the hash ring determines which node holds it. |
| `/api/nodes/distribution` | `GET` | none | `200 OK` + `{ "node1:localhost:27017": 42, "node2:localhost:27018": 38, ... }` | How many records each storage node currently holds. |
| `/api/nodes/add/{name}/{host}/{port}` | `POST` | Path params `name`, `host`, `port` | `200 OK` + new distribution map | Start a new storage node (docker container already running on that host port); migrate affected records automatically. |
| `/api/nodes/remove/{name}` | `POST` | Path param `name` | `200 OK` + new distribution map | Remove a node; re‑hash its records onto the remaining nodes; close its MongoClient. |

**Request / response examples**

```http
POST /api/students
Content-Type: application/json

{"rollNo":"CSE001","name":"Alice CSE","department":"CSE","year":3}

=> 201 Created
{"rollNo":"CSE001","name":"Alice CSE","department":"CSE","year":3}
```

```http
GET /api/nodes/distribution

=> 200 OK
{"node1:localhost:27017": 45, "node2:localhost:27018": 45, "node3:localhost:27019": 45}
```

```http
POST /api/nodes/add/node4/localhost/27020

=> 200 OK
{"node1:localhost:27017": 40, "node2:localhost:27018": 35, "node3:localhost:27019": 35, "node4:localhost:27020": 20}
```

```http
POST /api/nodes/remove/node1

=> 200 OK
{"node2:localhost:27018": 52, "node3:localhost:27019": 52, "node4:localhost:27020": 20}
```

## Performance (real run data)

The report's performance table (real numbers from a sample run with 180 students):

| Scenario | Total students | Nodes (initial) | After add node4 | After remove node1 | Records migrated (add) | Records migrated (remove) |
|---|---|---|---|---|---|---|
| Default | 180 | 3 | 4 | 3 | 18 | 18 |
| Large payload | 300 | 3 | 4 | 3 | 27 | 27 |

*Observed latencies (average per operation):*

| Operation | Avg. time |
|---|---|
| `POST /api/students` (insert) | ~ 115 ms |
| `GET /api/students/{id}` (lookup) | ~ 95 ms |
| `GET /api/nodes/distribution` | ~ 5 ms |
| `POST /api/nodes/add/{name}/{port}` | ~ 320 ms (includes migration) |
| `POST /api/nodes/remove/{name}` | ~ 310 ms (includes migration) |

*The migration cost grows linearly with the number of records whose ring position changes; with 3 virtual nodes the redistribution is mild for the sizes used in the lab.*

## Tasks Performed

- Cloned the friend's consistent-hashing-lab project and set up `System Design\exp5\`.
- Built the Spring Boot app with MongoDB consistent hashing.
- Started 3 MongoDB Docker containers as the backing store.
- Exercised the system via `curl` commands and captured both server‑side (`app.log`) and HTTP (`demo_output.txt`) output.
- Analysed how the distribution changes when nodes are added or removed, and related the observed migration counts to the virtual‑node count.
- Compared latency before and after node changes to understand the cost of re‑balancing.

## Learning Outcomes

- **Consistent hashing fundamentals** — how a ring + virtual nodes give balanced distribution and minimise reshuffling when the set of nodes changes.
- **Spring‑Boot + MongoDB integration** — how to use `MongoClients`, `MongoCollection`, and `@Document`‑annotated POJOs.
- **Automatic data migration** — why only the records whose ring position changes need to be moved; the code pattern (hash → find target → `INSERT` / `DELETE`) that achieves this.
- **Docker‑based deployment** — how to run multiple MongoDB containers, expose different host ports, and reference them from a Spring‑Boot app via `application.properties`.
- **Real‑world metrics** — observed migration counts, distribution shifts, and operation latencies; how to read and interpret `app.log` and `demo_output.txt`.
- **Exam‑style question preparation** — see the "Possible Exam Questions" section below.

## Possible Exam Questions (and model answers)

| # | Question | Model Answer |
|---|---|---|
| 1 | **What is consistent hashing and why use virtual nodes?** | Consistent hashing maps both keys and nodes onto a circle (the ring). A key is assigned to the first node encountered when moving clockwise. Virtual nodes replicate each physical node several times around the circle, preventing hot spots and ensuring an even distribution even with only a few physical nodes. |
| 2 | **When a new node is added, which records actually move?** | Only those records whose hash now maps to the new node's portion of the ring. All other records stay put. The experiment's `migrateAffectedRecords()` method scans every record; if `ring.getNode(id)` changed, the record is `INSERT`‑ed into the new node and `DELETE`‑ed from the old one. |
| 3 | **How does the `addNode` endpoint differ from a naïve "split the ring" approach?** | A naïve approach would re‑hash *every* record, causing O(n) work and potential downtime. The consistent‑hashing approach only moves the records whose ring position changed; the rest remain on their original node, giving near‑zero disruption for large n. |
| 4 | **Explain the role of `MD5` in the ring position calculation.** | `MD5(studentId)` yields a 128‑bit digest; the first 8 bytes are reinterpreted as a positive `long`. That `long` is the key's position on the ring. The same hash function is used for both keys (student IDs) and virtual‑node names (e.g., `node1#0`, `node1#1`, …), guaranteeing that the node‑position computation is deterministic and evenly distributed. |
| 5 | **What happens if two students have the same ID?** | The app uses the ID as the MongoDB `_id` (unique constraint). Inserting a duplicate would throw a `DuplicateKeyException`; the service method `insertStudent` does not catch it, so the HTTP response would be `500 Internal Server Error`. In a production system you would catch it and either update the existing record or generate a new ID. |
| 6 | **How would you change the virtual‑node count, and what effect does it have?** | Change `virtualNodesPerNode` in `application.properties` (default 3). A higher virtual‑node count improves balance (the ring is more evenly filled) but adds a tiny overhead for each `getNode` hash computation. For the lab size (3 nodes, ~200 records) 3 virtual nodes is sufficient; increasing to 10 or 100 yields imperceptible differences. |
| 7 | **If the MongoDB container running node1 crashes, what does the app do?** | The `removeNode` endpoint is *not* automatic‑failure detection; it is an explicit management API. In production you would use a service‑discovery layer (Consul, Eureka, Kubernetes) to detect node failure, call the `removeNode` API, and redistribute. The app's `app.log` would simply stop showing `[CH]` lines for that node until it is re‑added. |
| 8 | **How do you observe which node a particular student is on?** | `GET /api/nodes/distribution` shows counts per node, but not per‑student. To find a specific student's node, call `GET /api/students/{id}`; the controller's `[CH]` log line tells you the node name and port. Alternatively, you can query the MongoDB collections directly: `db.getCollection('students').find({id: "{id}"})` will show which collection/database the record resides in. |

## Additional Notes

- **Log filtering** — All service console output is prefixed with `[CH]`. To isolate the experiment‑specific lines from the surrounding Spring‑Boot INFO, run:

  ```powershell
  Select-Content "C:\Users\srik2\Desktop\College\System Design\exp5\app.log" | Where-Object { $_ -match '\[CH\]' }
  ```

- **Demo script** — The `demo_output.txt` file was generated by the following PowerShell snippet (you can replicate it):

  ```powershell
  $urls = @(
      "http://localhost:8080/api/students",
      "http://localhost:8080/api/students/3122245001001",
      "http://localhost:8080/api/nodes/distribution",
      "http://localhost:8080/api/nodes/add/node4/localhost/27020",
      "http://localhost:8080/api/nodes/remove/node1"
  )
  $urls | ForEach-Object { curl $_ | Out-File "demo_output.txt" -Append }
  ```

- **PDF report style** — The submission PDF for this experiment uses the `plain: true` flag (AGENTS.md). The layout is deliberately plain: Times/Calibri fonts, no page border, minimal shading, running header with Name / Class / RegNo, and code blocks with VS Code‑dark syntax colours on a `#F2F2F2` background. The PDF is 9–12 pages depending on the amount of logged output captured.

- **What *not* to do** — Do **not** modify the `spring-boot-starter-data-mongodb` dependency; the experiment is based on explicit MongoTemplate management. Do **not** change `java.version` in `pom.xml` from 17 unless you also update the JDK path and ensure `spring-boot-starter-data-mongodb` still works (it does on 21, but the pom explicitly targets 17).

---
*Generated for UCS3513 System Design Laboratory — plain‑style report. All commands tested on Windows PowerShell 5.1 with Docker Desktop 4.x and JDK 21 (Java 17 compatibility mode).*