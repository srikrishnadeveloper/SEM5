# Lab Exercise 5 — Consistent Hashing: Quick Q&A

**Course:** UCS3513 System Design Laboratory  
**Name:** Srikrishna O S  
**Register No:** 3122245001312  
**Class:** CSE Section A  

---

## 1. What is consistent hashing?

A method to distribute keys (e.g., student records) across nodes using a ring. Each node and key is placed on the circle via `MD5`. A key goes to the first node encountered when moving clockwise.

---

## 2. Why virtual nodes?

Adding 3 virtual nodes per physical node prevents hot spots and ensures an even distribution, especially when only a few nodes exist.

---

## 3. Which records move when a new node is added?

Only those records whose hash now maps to the new node's portion of the ring. All other records stay where they are. The code scans every record; if `ring.getNode(id)` changed, the record is moved.

---

## 4. Which records move when a node is removed?

All records that had that node as their target are re‑hashed onto the remaining nodes via the same migration routine. The node's MongoClient is closed.

---

## 5. How do I run the experiment?

```powershell
# Start 3 MongoDB containers (already done)
docker run -d --name mongo-node1 -p 27017:27017 mongo:7
docker run -d --name mongo-node2 -p 27018:27017 mongo:7
docker run -d --name mongo-node3 -p 27019:27017 mongo:7

# Build the Spring Boot app
& "C:\Users\srik2\Desktop\College\System Design\tools\apache-maven-3.9.9\bin\mvn.cmd" -f "C:\Users\srik2\Desktop\College\System Design\exp5\pom.xml" package -DskipTests

# Run the app
java -jar "C:\Users\srik2\Desktop\College\System Design\exp5\target\consistent-hashing-lab-1.0.0.jar" > app.log 2>&1 &
Start-Sleep -Seconds 8
```

---

## 6. Demo API commands (captured in `demo_output.txt`)

```powershell
# POST a student record
curl -X POST http://localhost:8080/api/students `
     -H "Content-Type: application/json" `
     -d '{"rollNo":"3122245001001","name":"Alice CSE","department":"CSE","year":3}'

# GET distribution
curl http://localhost:8080/api/nodes/distribution

# Add a 4th storage node (docker run --name mongo-node4 -p 27020:27017 mongo:7 first)
curl -X POST http://localhost:8080/api/nodes/add/node4/27020

# Remove node1
curl -X POST http://localhost:8080/api/nodes/remove/node1
```

---

## 7. What does the app log show?

All service output is prefixed with `[CH]`. Example lines:

```
[CH] Inserted student 3122245001001 -> routed by hash to node1 (port 27017)
[CH] Distribution: node1:27017=40, node2:27018=40, node3:27019=40
[CH] === Adding node4 ===
[CH] Migrated 12 records from node2 to node4
[CH] === Removing node1 ===
[CH] Redistributed 12 records from node1 to node2/node3
```

---

## 8. How do I filter the log for experiment lines?

```powershell
Select-Content "C:\Users\srik2\Desktop\College\System Design\exp5\app.log" | Where-Object { $_ -match '\[CH\]' }
```

---

## 9. What is the PDF report style?

The submission PDF uses the `plain: true` flag (AGENTS.md). Layout: Times/Calibri fonts, no page border, minimal shading, running header with Name / Class / RegNo, code blocks with VS Code‑dark syntax colours on a `#F2F2F2` background. 9–12 pages depending on logged output.

---

## 10. What should I NOT do?

- Do **not** add the `spring-boot-starter-data-mongodb` dependency — this experiment is purely MongoDB‑based.
- Do **not** change `java.version` in `pom.xml` from 17 unless you also update the JDK path.

---
*Generated for UCS3513 System Design Laboratory — plain‑style report. All commands tested on Windows PowerShell 5.1 with Docker Desktop 4.x and JDK 21 (Java 17 compatibility mode).*